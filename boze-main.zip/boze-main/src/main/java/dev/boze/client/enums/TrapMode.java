package dev.boze.client.enums;

public enum TrapMode {
    Flat,
    Tall,
    Top;

    private static final TrapMode[] field1732 = method849();

    private static TrapMode[] method849() {
        return new TrapMode[]{Flat, Tall, Top};
    }
}
