package dev.boze.client.enums;

public enum GoldenAppleMode {
    Enc,
    Crap,
    Both;

    private static final GoldenAppleMode[] field37 = method32();

    private static GoldenAppleMode[] method32() {
        return new GoldenAppleMode[]{Enc, Crap, Both};
    }
}
