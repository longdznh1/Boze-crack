package dev.boze.client.font;

import java.io.File;

public class Font {
    public final String field1964;
    public final File field1965;

    public Font(String var1, File var2) {
        this.field1964 = var1;
        this.field1965 = var2;
    }
}
