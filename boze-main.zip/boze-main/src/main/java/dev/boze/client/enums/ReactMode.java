package dev.boze.client.enums;

public enum ReactMode {
    Tick,
    Packet;

    private static final ReactMode[] field1723 = method841();

    private static ReactMode[] method841() {
        return new ReactMode[]{Tick, Packet};
    }
}
