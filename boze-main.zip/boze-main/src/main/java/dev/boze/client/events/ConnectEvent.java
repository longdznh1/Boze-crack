package dev.boze.client.events;

public class ConnectEvent {
    private static final ConnectEvent field1911 = new ConnectEvent();

    public static ConnectEvent method1057() {
        return field1911;
    }
}
