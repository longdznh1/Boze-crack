package dev.boze.client.enums;

public enum StepMode {
    Vanilla,
    NCP,
    NCPStrict;

    private static final StepMode[] field1653 = method772();

    private static StepMode[] method772() {
        return new StepMode[]{Vanilla, NCP, NCPStrict};
    }
}
