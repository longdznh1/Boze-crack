package dev.boze.client.enums;

public enum TunnelShader {
    Normal,
    Image;

    private static final TunnelShader[] field1668 = method787();

    private static TunnelShader[] method787() {
        return new TunnelShader[]{Normal, Image};
    }
}
