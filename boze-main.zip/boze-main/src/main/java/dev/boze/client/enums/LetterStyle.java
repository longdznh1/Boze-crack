package dev.boze.client.enums;

public enum LetterStyle {
    Normal,
    lowercase,
    UPPERCASE;

    private static final LetterStyle[] field1657 = method776();

    private static LetterStyle[] method776() {
        return new LetterStyle[]{Normal, lowercase, UPPERCASE};
    }
}
