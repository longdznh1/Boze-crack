package dev.boze.client.enums;

public enum PlayerAimPoint {
    Distance,
    Angle;

    private static final PlayerAimPoint[] field1784 = method895();

    private static PlayerAimPoint[] method895() {
        return new PlayerAimPoint[]{Distance, Angle};
    }
}
