package dev.boze.client.enums;

public enum PlaceMode {
    Vanilla,
    Packet;

    // $VF: synthetic method
    private static PlaceMode[] method818() {
        return new PlaceMode[]{Vanilla, Packet};
    }
}
