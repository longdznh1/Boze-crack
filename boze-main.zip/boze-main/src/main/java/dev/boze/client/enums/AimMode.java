package dev.boze.client.enums;

public enum AimMode {
    Feet,
    Body,
    Eyes;

    private static final AimMode[] field1789 = method900();

    private static AimMode[] method900() {
        return new AimMode[]{Feet, Body, Eyes};
    }
}
