package dev.boze.client.enums;

public enum ThrowPotStage {
    Throw,
    SwapBack;

    private static final ThrowPotStage[] field40 = method35();

    private static ThrowPotStage[] method35() {
        return new ThrowPotStage[]{Throw, SwapBack};
    }
}
