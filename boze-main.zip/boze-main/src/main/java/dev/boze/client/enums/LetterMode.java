package dev.boze.client.enums;

public enum LetterMode {
    Text,
    Icon,
    Both;

    private static final LetterMode[] field24 = method19();

    private static LetterMode[] method19() {
        return new LetterMode[]{Text, Icon, Both};
    }
}
