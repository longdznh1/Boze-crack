package dev.boze.client.enums;

public enum CheckEntityMode {
    Off,
    NotCrystals,
    All;

    private static final CheckEntityMode[] field27 = method22();

    private static CheckEntityMode[] method22() {
        return new CheckEntityMode[]{Off, NotCrystals, All};
    }
}
