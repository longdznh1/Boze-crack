package dev.boze.client.events;

public class HandleInputEvent {
    private static final HandleInputEvent field1923 = new HandleInputEvent();

    public static HandleInputEvent method1064() {
        return field1923;
    }
}
