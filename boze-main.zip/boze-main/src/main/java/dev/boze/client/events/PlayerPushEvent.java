package dev.boze.client.events;

public class PlayerPushEvent extends CancelableEvent {
    private static final PlayerPushEvent INSTANCE = new PlayerPushEvent();

    public static PlayerPushEvent method1083() {
        INSTANCE.method1021(false);
        return INSTANCE;
    }
}
