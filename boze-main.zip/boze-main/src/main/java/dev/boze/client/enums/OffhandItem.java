package dev.boze.client.enums;

public enum OffhandItem {
    None,
    Totem,
    GApple,
    Crystal,
    Integration,
    Binds;

    private static final OffhandItem[] field1788 = method899();

    private static OffhandItem[] method899() {
        return new OffhandItem[]{None, Totem, GApple, Crystal, Integration, Binds};
    }
}
