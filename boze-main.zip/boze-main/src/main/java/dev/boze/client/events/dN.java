package dev.boze.client.events;

public class dN extends CancelableEvent {
    private static final dN field1891 = new dN();

    public static dN method1035() {
        field1891.method1021(false);
        return field1891;
    }
}
