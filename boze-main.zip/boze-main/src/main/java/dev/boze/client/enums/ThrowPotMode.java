package dev.boze.client.enums;

public enum ThrowPotMode {
    Buff,
    DeBuff
}
