package dev.boze.client.enums;

public enum CountMode {
    Tick,
    Second;

    private static final CountMode[] field1729 = method847();

    private static CountMode[] method847() {
        return new CountMode[]{Tick, Second};
    }
}
