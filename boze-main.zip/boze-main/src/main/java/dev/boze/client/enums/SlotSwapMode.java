package dev.boze.client.enums;

public enum SlotSwapMode {
    Normal,
    Alt;

    private static final SlotSwapMode[] field1692 = method811();

    private static SlotSwapMode[] method811() {
        return new SlotSwapMode[]{Normal, Alt};
    }
}
