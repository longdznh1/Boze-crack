package dev.boze.client.enums;

public enum PressMode {
    Toggle,
    Hold;

    // $VF: synthetic method
    private static PressMode[] method922() {
        return new PressMode[]{Toggle, Hold};
    }
}
