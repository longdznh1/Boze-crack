package dev.boze.client.enums;

public enum AimAssistGunPoint {
    Off,
    LeftClick,
    RightClick;

    private static final AimAssistGunPoint[] field1716 = method834();

    private static AimAssistGunPoint[] method834() {
        return new AimAssistGunPoint[]{Off, LeftClick, RightClick};
    }
}
