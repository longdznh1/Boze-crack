package dev.boze.client.enums;

public enum BlockPlaceMode {
    Normal,
    Mouse;

    private static final BlockPlaceMode[] field1768 = method879();

    private static BlockPlaceMode[] method879() {
        return new BlockPlaceMode[]{Normal, Mouse};
    }
}
