package dev.boze.client.enums;

public enum BowspamMode {
    Anarchy,
    Ghost;

    private static final BowspamMode[] field1751 = method866();

    private static BowspamMode[] method866() {
        return new BowspamMode[]{Anarchy, Ghost};
    }
}
