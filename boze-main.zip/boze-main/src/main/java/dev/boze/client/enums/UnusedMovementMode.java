package dev.boze.client.enums;

enum UnusedMovementMode {
    Off,
    Strong,
    Strict;

    private static final UnusedMovementMode[] field23 = method18();

    private static UnusedMovementMode[] method18() {
        return new UnusedMovementMode[]{Off, Strong, Strict};
    }
}
