package dev.boze.client.enums;

public enum AuraAntiBlock {
    Off,
    On,
    Always;

    private static final AuraAntiBlock[] field1796 = method907();

    private static AuraAntiBlock[] method907() {
        return new AuraAntiBlock[]{Off, On, Always};
    }
}
