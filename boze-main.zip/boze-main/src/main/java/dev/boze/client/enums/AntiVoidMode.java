package dev.boze.client.enums;

public enum AntiVoidMode {
    Ghost,
    Anarchy;

    private static final AntiVoidMode[] field1684 = method803();

    private static AntiVoidMode[] method803() {
        return new AntiVoidMode[]{Ghost, Anarchy};
    }
}
