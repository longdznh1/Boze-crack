package dev.boze.client.enums;

public enum MurderMysteryWeapon {
    Hypixel,
    Sword,
    Custom;

    private static final MurderMysteryWeapon[] field1644 = method763();

    private static MurderMysteryWeapon[] method763() {
        return new MurderMysteryWeapon[]{Hypixel, Sword, Custom};
    }
}
