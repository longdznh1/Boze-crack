package dev.boze.client.enums;

public enum ModuleState {
    Off,
    On;

    private static final ModuleState[] field1670 = method789();

    private static ModuleState[] method789() {
        return new ModuleState[]{Off, On};
    }
}
