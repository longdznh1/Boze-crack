package dev.boze.client.enums;

public enum JesusMode {
    Normal,
    Strict;

    private static final JesusMode[] field1725 = method843();

    private static JesusMode[] method843() {
        return new JesusMode[]{Normal, Strict};
    }
}
