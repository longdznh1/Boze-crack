package dev.boze.client.enums;

public enum HoleTPMode {
    Normal,
    Path,
    Baritone;

    private static final HoleTPMode[] field1683 = method802();

    private static HoleTPMode[] method802() {
        return new HoleTPMode[]{Normal, Path, Baritone};
    }
}
