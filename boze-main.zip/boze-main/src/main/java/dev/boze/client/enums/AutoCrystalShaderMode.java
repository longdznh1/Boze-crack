package dev.boze.client.enums;

public enum AutoCrystalShaderMode {
    Normal,
    Image;

    private static final AutoCrystalShaderMode[] field7 = method3();

    private static AutoCrystalShaderMode[] method3() {
        return new AutoCrystalShaderMode[]{Normal, Image};
    }
}
