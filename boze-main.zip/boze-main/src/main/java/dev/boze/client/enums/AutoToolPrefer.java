package dev.boze.client.enums;

public enum AutoToolPrefer {
    SilkTouch,
    Fortune,
    Both;

    private static final AutoToolPrefer[] field56 = method49();

    private static AutoToolPrefer[] method49() {
        return new AutoToolPrefer[]{SilkTouch, Fortune, Both};
    }
}
