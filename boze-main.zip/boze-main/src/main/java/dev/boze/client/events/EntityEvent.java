package dev.boze.client.events;

import net.minecraft.entity.Entity;

public class EntityEvent extends CancelableEvent {
    public Entity entity;
}
