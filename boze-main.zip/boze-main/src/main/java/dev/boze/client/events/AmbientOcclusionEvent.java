package dev.boze.client.events;

public class AmbientOcclusionEvent {
    private static final AmbientOcclusionEvent field1899 = new AmbientOcclusionEvent();
    public float field1900 = -1.0F;

    public static AmbientOcclusionEvent method1050() {
        field1899.field1900 = -1.0F;
        return field1899;
    }
}
