package dev.boze.client.enums;

public enum AutoArmorElytra {
    Off,
    Bind,
    ElytraFly,
    Always;

    private static final AutoArmorElytra[] field52 = method45();

    private static AutoArmorElytra[] method45() {
        return new AutoArmorElytra[]{Off, Bind, ElytraFly, Always};
    }
}
