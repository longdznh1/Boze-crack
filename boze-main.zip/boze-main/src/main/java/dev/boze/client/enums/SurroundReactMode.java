package dev.boze.client.enums;

public enum SurroundReactMode {
    Tick,
    Packet;

    private static final SurroundReactMode[] field1640 = method759();

    private static SurroundReactMode[] method759() {
        return new SurroundReactMode[]{Tick, Packet};
    }
}
