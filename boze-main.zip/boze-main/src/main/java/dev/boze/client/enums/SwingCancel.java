package dev.boze.client.enums;

public enum SwingCancel {
    Off,
    Normal,
    Strict;

    private static final SwingCancel[] field1660 = method779();

    private static SwingCancel[] method779() {
        return new SwingCancel[]{Off, Normal, Strict};
    }
}
