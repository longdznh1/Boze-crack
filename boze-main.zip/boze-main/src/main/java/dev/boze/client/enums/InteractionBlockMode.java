package dev.boze.client.enums;

public enum InteractionBlockMode {
    Obsidian,
    BlastProof,
    Custom;

    private static final InteractionBlockMode[] field1740 = method855();

    private static InteractionBlockMode[] method855() {
        return new InteractionBlockMode[]{Obsidian, BlastProof, Custom};
    }
}
