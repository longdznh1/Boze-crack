package dev.boze.client.enums;

public enum ESPMode {
    Simple,
    Shader;

    private static final ESPMode[] field1787 = method898();

    private static ESPMode[] method898() {
        return new ESPMode[]{Simple, Shader};
    }
}
