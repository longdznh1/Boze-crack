package dev.boze.client.enums;

public enum AutoSelectSafetyMode {
    AutoCrystal,
    Custom;

    private static final AutoSelectSafetyMode[] field1748 = method863();

    private static AutoSelectSafetyMode[] method863() {
        return new AutoSelectSafetyMode[]{AutoCrystal, Custom};
    }
}
