package dev.boze.client.enums;

public enum PriorityMode {
    Highest,
    Lowest;

    private static final PriorityMode[] field1785 = method896();

    private static PriorityMode[] method896() {
        return new PriorityMode[]{Highest, Lowest};
    }
}
