package dev.boze.client.enums;

public enum WaypointShaderMode {
    Normal,
    Image;

    private static final WaypointShaderMode[] field1752 = method867();

    private static WaypointShaderMode[] method867() {
        return new WaypointShaderMode[]{Normal, Image};
    }
}
