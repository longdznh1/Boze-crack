package dev.boze.client.enums;

public enum PositionMode {
    Feet,
    Body,
    Head;

    private static final PositionMode[] field1749 = method864();

    private static PositionMode[] method864() {
        return new PositionMode[]{Feet, Body, Head};
    }
}
