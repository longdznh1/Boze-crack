package dev.boze.client.enums;

public enum RotationMode {
    Sequential,
    Vanilla;

    private static final RotationMode[] field1758 = method872();

    private static RotationMode[] method872() {
        return new RotationMode[]{Sequential, Vanilla};
    }
}
