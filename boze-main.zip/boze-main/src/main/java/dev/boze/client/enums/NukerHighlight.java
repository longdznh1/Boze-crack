package dev.boze.client.enums;

public enum NukerHighlight {
    Normal,
    Complex;

    private static final NukerHighlight[] field36 = method31();

    private static NukerHighlight[] method31() {
        return new NukerHighlight[]{Normal, Complex};
    }
}
