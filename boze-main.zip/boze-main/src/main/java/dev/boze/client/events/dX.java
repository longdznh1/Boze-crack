package dev.boze.client.events;

public class dX extends CancelableEvent {
}
