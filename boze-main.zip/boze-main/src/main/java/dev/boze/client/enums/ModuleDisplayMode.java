package dev.boze.client.enums;

public enum ModuleDisplayMode {
    None,
    Icons,
    Bind,
    State;

    private static final ModuleDisplayMode[] field1712 = method830();

    private static ModuleDisplayMode[] method830() {
        return new ModuleDisplayMode[]{None, Icons, Bind, State};
    }
}
