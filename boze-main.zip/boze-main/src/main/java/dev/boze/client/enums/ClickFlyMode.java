package dev.boze.client.enums;

public enum ClickFlyMode {
    Once,
    RightClick,
    Bind;

    private static final ClickFlyMode[] field1803 = method913();

    private static ClickFlyMode[] method913() {
        return new ClickFlyMode[]{Once, RightClick, Bind};
    }
}
