package dev.boze.client.enums;

public enum AutoUpgradeMode {
    Anarchy,
    Ghost;

    private static final AutoUpgradeMode[] field1756 = method870();

    private static AutoUpgradeMode[] method870() {
        return new AutoUpgradeMode[]{Anarchy, Ghost};
    }
}
