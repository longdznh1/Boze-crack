package dev.boze.client.enums;

public enum AnticheatMode {
    NCP,
    Grim;

    // $VF: synthetic method
    private static AnticheatMode[] method835() {
        return new AnticheatMode[]{NCP, Grim};
    }
}
