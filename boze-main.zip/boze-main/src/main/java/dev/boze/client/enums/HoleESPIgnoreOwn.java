package dev.boze.client.enums;

public enum HoleESPIgnoreOwn {
    Off,
    Basic,
    Eye,
    Feet;

    private static final HoleESPIgnoreOwn[] field1744 = method859();

    private static HoleESPIgnoreOwn[] method859() {
        return new HoleESPIgnoreOwn[]{Off, Basic, Eye, Feet};
    }
}
