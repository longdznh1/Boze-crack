package dev.boze.client.enums;

public enum AutoWalkMode {
    Key,
    Input,
    Baritone;

    private static final AutoWalkMode[] field1663 = method782();

    private static AutoWalkMode[] method782() {
        return new AutoWalkMode[]{Key, Input, Baritone};
    }
}
