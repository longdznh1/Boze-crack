package dev.boze.client.enums;

public enum ColorTypes {
    ALL,
    SIMPLE,
    STATIC;

    private static final ColorTypes[] field1772 = method883();

    private static ColorTypes[] method883() {
        return new ColorTypes[]{ALL, SIMPLE, STATIC};
    }
}
