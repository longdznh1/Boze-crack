package dev.boze.client.enums;

public enum NotificationLength {
    Normal,
    Limited,
    Popup;

    // $VF: synthetic method
    private static NotificationLength[] method880() {
        return new NotificationLength[]{Normal, Limited, Popup};
    }
}
