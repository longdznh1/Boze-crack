package dev.boze.client.enums;

public enum SelfFillMode {
    Burrow,
    Web;

    private static final SelfFillMode[] field1675 = method794();

    private static SelfFillMode[] method794() {
        return new SelfFillMode[]{Burrow, Web};
    }
}
