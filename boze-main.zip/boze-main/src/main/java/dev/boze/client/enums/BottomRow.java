package dev.boze.client.enums;

public enum BottomRow {
    AddClose,
    TextAddClose;

    private static final BottomRow[] field1667 = method786();

    private static BottomRow[] method786() {
        return new BottomRow[]{AddClose, TextAddClose};
    }
}
