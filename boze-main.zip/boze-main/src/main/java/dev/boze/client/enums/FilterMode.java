package dev.boze.client.enums;

public enum FilterMode {
    Off,
    Whitelist,
    Blacklist;

    // $VF: synthetic method
    private static FilterMode[] method20() {
        return new FilterMode[]{Off, Whitelist, Blacklist};
    }
}
