package dev.boze.client.enums;

public enum ModuleColors {
    Random,
    Consistent;

    private static final ModuleColors[] field1661 = method780();

    private static ModuleColors[] method780() {
        return new ModuleColors[]{Random, Consistent};
    }
}
