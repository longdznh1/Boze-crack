package dev.boze.client.enums;

public enum ChamsShaderMode {
    Normal,
    Image;

    private static final ChamsShaderMode[] field1779 = method890();

    private static ChamsShaderMode[] method890() {
        return new ChamsShaderMode[]{Normal, Image};
    }
}
