package dev.boze.client.enums;

public enum BlockHighlightShader {
    Normal,
    Image;

    private static final BlockHighlightShader[] field1721 = method839();

    private static BlockHighlightShader[] method839() {
        return new BlockHighlightShader[]{Normal, Image};
    }
}
