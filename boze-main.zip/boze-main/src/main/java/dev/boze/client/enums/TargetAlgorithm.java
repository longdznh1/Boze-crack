package dev.boze.client.enums;

public enum TargetAlgorithm {
    Distance,
    Health;

    private static final TargetAlgorithm[] field47 = method40();

    private static TargetAlgorithm[] method40() {
        return new TargetAlgorithm[]{Distance, Health};
    }
}
