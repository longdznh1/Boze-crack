package dev.boze.client.enums;

public enum BedTargetMode {
    Off,
    Semi,
    Full;

    private static final BedTargetMode[] field1651 = method770();

    private static BedTargetMode[] method770() {
        return new BedTargetMode[]{Off, Semi, Full};
    }
}
