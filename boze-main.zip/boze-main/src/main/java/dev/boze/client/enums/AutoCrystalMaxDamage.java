package dev.boze.client.enums;

public enum AutoCrystalMaxDamage {
    Combined,
    MaxSelfDmg,
    Balance;

    private static final AutoCrystalMaxDamage[] field1647 = method766();

    private static AutoCrystalMaxDamage[] method766() {
        return new AutoCrystalMaxDamage[]{Combined, MaxSelfDmg, Balance};
    }
}
