package dev.boze.client.enums;

public enum BlockHighlightMode {
    Normal,
    Flat,
    Complex;

    private static final BlockHighlightMode[] field1742 = method857();

    private static BlockHighlightMode[] method857() {
        return new BlockHighlightMode[]{Normal, Flat, Complex};
    }
}
