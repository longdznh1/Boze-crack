package dev.boze.client.enums;

public enum ExtraChatMode {
    Anarchy,
    Ghost;

    private static final ExtraChatMode[] field33 = method28();

    private static ExtraChatMode[] method28() {
        return new ExtraChatMode[]{Anarchy, Ghost};
    }
}
