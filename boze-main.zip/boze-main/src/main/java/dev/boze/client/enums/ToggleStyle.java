package dev.boze.client.enums;

public enum ToggleStyle {
    Switch,
    Circle,
    Check;

    private static final ToggleStyle[] field1690 = method809();

    private static ToggleStyle[] method809() {
        return new ToggleStyle[]{Switch, Circle, Check};
    }
}
