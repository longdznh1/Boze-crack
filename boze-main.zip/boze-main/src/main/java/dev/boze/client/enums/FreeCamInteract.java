package dev.boze.client.enums;

public enum FreeCamInteract {
    Player,
    Camera,
    Dynamic;

    private static final FreeCamInteract[] field1649 = method768();

    private static FreeCamInteract[] method768() {
        return new FreeCamInteract[]{Player, Camera, Dynamic};
    }
}
