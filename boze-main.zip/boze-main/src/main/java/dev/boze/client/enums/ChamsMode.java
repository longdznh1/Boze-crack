package dev.boze.client.enums;

public enum ChamsMode {
    Normal,
    Shader,
    Both;

    private static final ChamsMode[] field1711 = method829();

    private static ChamsMode[] method829() {
        return new ChamsMode[]{Normal, Shader, Both};
    }
}
