package dev.boze.client.enums;

public enum AntiBotTabList {
    Off,
    On,
    ZeroPing;

    private static final AntiBotTabList[] field1691 = method810();

    private static AntiBotTabList[] method810() {
        return new AntiBotTabList[]{Off, On, ZeroPing};
    }
}
