package dev.boze.client.enums;

public enum NoSlowWebs {
    Off,
    Vanilla,
    Grim;

    private static final NoSlowWebs[] field41 = method36();

    private static NoSlowWebs[] method36() {
        return new NoSlowWebs[]{Off, Vanilla, Grim};
    }
}
