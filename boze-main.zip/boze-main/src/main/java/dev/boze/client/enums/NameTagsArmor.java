package dev.boze.client.enums;

public enum NameTagsArmor {
    Off,
    Normal,
    Reverse;

    private static final NameTagsArmor[] field57 = method50();

    private static NameTagsArmor[] method50() {
        return new NameTagsArmor[]{Off, Normal, Reverse};
    }
}
