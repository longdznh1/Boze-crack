package dev.boze.client.enums;

public enum FastFallHorizontal {
    Cancel,
    Normal,
    Boost;

    private static final FastFallHorizontal[] field1693 = method812();

    private static FastFallHorizontal[] method812() {
        return new FastFallHorizontal[]{Cancel, Normal, Boost};
    }
}
