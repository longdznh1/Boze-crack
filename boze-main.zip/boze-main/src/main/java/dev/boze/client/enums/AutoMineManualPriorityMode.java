package dev.boze.client.enums;

public enum AutoMineManualPriorityMode {
    Off,
    On,
    Force;

    private static final AutoMineManualPriorityMode[] field1701 = method821();

    private static AutoMineManualPriorityMode[] method821() {
        return new AutoMineManualPriorityMode[]{Off, On, Force};
    }
}
