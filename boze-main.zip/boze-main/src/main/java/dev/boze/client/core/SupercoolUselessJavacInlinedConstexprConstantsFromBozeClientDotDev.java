package dev.boze.client.core;

public class SupercoolUselessJavacInlinedConstexprConstantsFromBozeClientDotDev {
    public static final int field1872 = 400;
    public static final int field1873 = 350;
    public static final int field1874 = 250;
    public static final int field1875 = 200;
    public static final int field1876 = 150;
    public static final int field1877 = 149;
    public static final int field1878 = 125;
    public static final int field1879 = 76;
    public static final int field1880 = 75;
    public static final int field1881 = 70;
    public static final int field1882 = 26;
    public static final int field1883 = 25;
    public static final int field1884 = 20;
    public static final int field1885 = 7;
    public static final int field1886 = 5;
}
