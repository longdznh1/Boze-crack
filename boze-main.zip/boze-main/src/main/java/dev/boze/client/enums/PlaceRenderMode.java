package dev.boze.client.enums;

public enum PlaceRenderMode {
    Simple,
    Shader;

    private static final PlaceRenderMode[] field1799 = method909();

    private static PlaceRenderMode[] method909() {
        return new PlaceRenderMode[]{Simple, Shader};
    }
}
