package dev.boze.client.enums;

public enum AutoSelectMode {
    Smart,
    Always,
    Bind;

    private static final AutoSelectMode[] field1741 = method856();

    private static AutoSelectMode[] method856() {
        return new AutoSelectMode[]{Smart, Always, Bind};
    }
}
