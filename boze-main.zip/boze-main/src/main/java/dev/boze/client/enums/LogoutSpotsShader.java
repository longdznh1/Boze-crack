package dev.boze.client.enums;

public enum LogoutSpotsShader {
    Normal,
    Image;

    private static final LogoutSpotsShader[] field1637 = method756();

    private static LogoutSpotsShader[] method756() {
        return new LogoutSpotsShader[]{Normal, Image};
    }
}
