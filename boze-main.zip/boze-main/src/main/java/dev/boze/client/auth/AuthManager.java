package dev.boze.client.auth;

public class AuthManager {
    public static void main(String[] args) {
        System.out.println("Hello world!");
    }
}