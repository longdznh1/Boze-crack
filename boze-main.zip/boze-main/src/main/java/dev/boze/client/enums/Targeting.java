package dev.boze.client.enums;

public enum Targeting {
    Single,
    Multi;

    private static final Targeting[] field34 = method29();

    private static Targeting[] method29() {
        return new Targeting[]{Single, Multi};
    }
}
