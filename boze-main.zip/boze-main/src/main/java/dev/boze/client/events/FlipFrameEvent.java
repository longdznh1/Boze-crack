package dev.boze.client.events;

public class FlipFrameEvent extends CancelableEvent {
    private static final FlipFrameEvent INSTANCE = new FlipFrameEvent();

    public static FlipFrameEvent method1039() {
        INSTANCE.method1021(false);
        return INSTANCE;
    }
}
