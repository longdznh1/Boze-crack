package dev.boze.client.enums;

public enum ReplenishMode {
    Anarchy,
    Ghost;

    private static final ReplenishMode[] field1734 = method851();

    private static ReplenishMode[] method851() {
        return new ReplenishMode[]{Anarchy, Ghost};
    }
}
