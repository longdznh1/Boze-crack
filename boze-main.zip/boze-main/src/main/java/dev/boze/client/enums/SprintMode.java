package dev.boze.client.enums;

public enum SprintMode {
    NCP,
    Grim,
    Ghost;

    private static final SprintMode[] field1746 = method861();

    private static SprintMode[] method861() {
        return new SprintMode[]{NCP, Grim, Ghost};
    }
}
