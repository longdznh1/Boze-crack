package dev.boze.client.events;

public class CrosshairEvent extends CancelableEvent {
    private static final CrosshairEvent field1888 = new CrosshairEvent();

    public static CrosshairEvent method1023() {
        field1888.method1021(false);
        return field1888;
    }
}
