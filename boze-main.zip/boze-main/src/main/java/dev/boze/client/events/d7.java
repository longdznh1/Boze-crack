package dev.boze.client.events;

public class d7 extends CancelableEvent {
    private static final d7 field1897 = new d7();

    public static d7 method1046() {
        field1897.method1021(false);
        return field1897;
    }
}
