package dev.boze.client.enums;

public enum CrystalOptimizerMode {
    EntityTrace,
    SetDead;

    private static final CrystalOptimizerMode[] field1669 = method788();

    private static CrystalOptimizerMode[] method788() {
        return new CrystalOptimizerMode[]{EntityTrace, SetDead};
    }
}
