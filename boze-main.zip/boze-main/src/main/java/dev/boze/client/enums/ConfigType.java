package dev.boze.client.enums;

public enum ConfigType {
    CONFIG,
    PROFILE;

    private static final ConfigType[] field1801 = method911();

    private static ConfigType[] method911() {
        return new ConfigType[]{CONFIG, PROFILE};
    }
}
