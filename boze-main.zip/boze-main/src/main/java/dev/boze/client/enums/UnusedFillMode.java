package dev.boze.client.enums;

enum UnusedFillMode {
    Opacity,
    Color;

    private static final UnusedFillMode[] field51 = method44();

    private static UnusedFillMode[] method44() {
        return new UnusedFillMode[]{Opacity, Color};
    }
}
