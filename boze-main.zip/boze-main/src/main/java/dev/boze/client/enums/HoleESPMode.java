package dev.boze.client.enums;

public enum HoleESPMode {
    Simple,
    Shader;

    private static final HoleESPMode[] field54 = method47();

    private static HoleESPMode[] method47() {
        return new HoleESPMode[]{Simple, Shader};
    }
}
