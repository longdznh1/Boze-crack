package dev.boze.client.enums;

public enum MiddleClickMode {
    Anarchy,
    Ghost;

    private static final MiddleClickMode[] field1812 = method921();

    private static MiddleClickMode[] method921() {
        return new MiddleClickMode[]{Anarchy, Ghost};
    }
}
