package dev.boze.client.enums;

public enum NoSlowInvMove {
    Off,
    On,
    NCPStrict;

    private static final NoSlowInvMove[] field1678 = method798();

    private static NoSlowInvMove[] method798() {
        return new NoSlowInvMove[]{Off, On, NCPStrict};
    }
}
