package dev.boze.client.enums;

public enum OffhandMode {
    Anarchy,
    Ghost;

    private static final OffhandMode[] field28 = method23();

    private static OffhandMode[] method23() {
        return new OffhandMode[]{Anarchy, Ghost};
    }
}
