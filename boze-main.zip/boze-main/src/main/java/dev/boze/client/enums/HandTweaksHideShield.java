package dev.boze.client.enums;

public enum HandTweaksHideShield {
    Off,
    On,
    Always;

    private static final HandTweaksHideShield[] field1714 = method832();

    private static HandTweaksHideShield[] method832() {
        return new HandTweaksHideShield[]{Off, On, Always};
    }
}
