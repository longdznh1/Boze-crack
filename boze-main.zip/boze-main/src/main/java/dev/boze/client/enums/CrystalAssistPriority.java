package dev.boze.client.enums;

public enum CrystalAssistPriority {
    Distance,
    FOV;

    private static final CrystalAssistPriority[] field1743 = method858();

    private static CrystalAssistPriority[] method858() {
        return new CrystalAssistPriority[]{Distance, FOV};
    }
}
