package dev.boze.client.enums;

public enum ScaffoldFilter {
    Off,
    Whitelist,
    Blacklist;

    private static final ScaffoldFilter[] field1800 = method910();

    private static ScaffoldFilter[] method910() {
        return new ScaffoldFilter[]{Off, Whitelist, Blacklist};
    }
}
