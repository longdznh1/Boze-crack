package dev.boze.client.enums;

public enum HoleESPOptimization {
    Off,
    Normal,
    Thread;

    private static final HoleESPOptimization[] field1745 = method860();

    private static HoleESPOptimization[] method860() {
        return new HoleESPOptimization[]{Off, Normal, Thread};
    }
}
