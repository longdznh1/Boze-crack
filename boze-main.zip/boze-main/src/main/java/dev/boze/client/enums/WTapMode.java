package dev.boze.client.enums;

public enum WTapMode {
    field1761,
    field1762;

    private static final WTapMode[] field1763 = method875();

    private static WTapMode[] method875() {
        return new WTapMode[]{field1761, field1762};
    }
}
