package dev.boze.client.enums;

public enum AutoSelectSortingMode {
    Distance,
    Health;

    private static final AutoSelectSortingMode[] field1718 = method836();

    private static AutoSelectSortingMode[] method836() {
        return new AutoSelectSortingMode[]{Distance, Health};
    }
}
