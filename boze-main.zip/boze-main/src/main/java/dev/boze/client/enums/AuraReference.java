package dev.boze.client.enums;

public enum AuraReference {
    Client,
    Server;

    private static final AuraReference[] field1713 = method831();

    private static AuraReference[] method831() {
        return new AuraReference[]{Client, Server};
    }
}
