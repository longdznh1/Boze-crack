package dev.boze.client.enums;

public enum InhibitMode {
    Off,
    On,
    Strict;

    private static final InhibitMode[] field1747 = method862();

    private static InhibitMode[] method862() {
        return new InhibitMode[]{Off, On, Strict};
    }
}
