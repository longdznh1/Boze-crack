package dev.boze.client.enums;

public enum AutoMineSwapbackMode {
    Off,
    Dynamic,
    Always;

    private static final AutoMineSwapbackMode[] field1682 = method801();

    private static AutoMineSwapbackMode[] method801() {
        return new AutoMineSwapbackMode[]{Off, Dynamic, Always};
    }
}
