package dev.boze.client.enums;

public enum HoleTPHoles {
    All,
    Safe;

    private static final HoleTPHoles[] field1706 = method825();

    private static HoleTPHoles[] method825() {
        return new HoleTPHoles[]{All, Safe};
    }
}
