package dev.boze.client.enums;

public enum FastFallMode {
    Normal,
    Step;

    private static final FastFallMode[] field1673 = method792();

    private static FastFallMode[] method792() {
        return new FastFallMode[]{Normal, Step};
    }
}
