package dev.boze.client.enums;

public enum SwingMode {
    Anarchy,
    Ghost;

    private static final SwingMode[] field26 = method21();

    private static SwingMode[] method21() {
        return new SwingMode[]{Anarchy, Ghost};
    }
}
