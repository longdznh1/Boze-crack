package dev.boze.client.enums;

public enum GUIMenu {
    Normal,
    AltManager;

    private static final GUIMenu[] field1811 = method920();

    private static GUIMenu[] method920() {
        return new GUIMenu[]{Normal, AltManager};
    }
}
