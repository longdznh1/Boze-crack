package dev.boze.client.enums;

public enum AnchorTriggerDefaultItem {
    Any,
    Anchor,
    Totem,
    Gapple,
    Crystal,
    Sword,
    Slot;

    private static final AnchorTriggerDefaultItem[] field21 = method16();

    private static AnchorTriggerDefaultItem[] method16() {
        return new AnchorTriggerDefaultItem[]{Any, Anchor, Totem, Gapple, Crystal, Sword, Slot};
    }
}
