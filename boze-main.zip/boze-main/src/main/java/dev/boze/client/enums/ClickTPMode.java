package dev.boze.client.enums;

public enum ClickTPMode {
    Once,
    RightClick,
    Bind;

    private static final ClickTPMode[] field1679 = method799();

    private static ClickTPMode[] method799() {
        return new ClickTPMode[]{Once, RightClick, Bind};
    }
}
