package dev.boze.client.enums;

public enum AutoMineMode {
    Auto,
    Manual,
    Bomber;

    private static final AutoMineMode[] field32 = method27();

    private static AutoMineMode[] method27() {
        return new AutoMineMode[]{Auto, Manual, Bomber};
    }
}
