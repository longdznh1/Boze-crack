package dev.boze.client.enums;

public enum SearchShader {
    Normal,
    Image;

    private static final SearchShader[] field14 = method9();

    private static SearchShader[] method9() {
        return new SearchShader[]{Normal, Image};
    }
}
