package dev.boze.client.enums;

public enum AlignMode {
    Left,
    Center,
    Right;

    private static final AlignMode[] field1638 = method757();

    private static AlignMode[] method757() {
        return new AlignMode[]{Left, Center, Right};
    }
}
