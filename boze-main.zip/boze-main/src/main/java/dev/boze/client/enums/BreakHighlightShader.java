package dev.boze.client.enums;

public enum BreakHighlightShader {
    Normal,
    Image;

    private static final BreakHighlightShader[] field1694 = method813();

    private static BreakHighlightShader[] method813() {
        return new BreakHighlightShader[]{Normal, Image};
    }
}
