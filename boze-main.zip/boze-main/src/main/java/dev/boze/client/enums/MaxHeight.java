package dev.boze.client.enums;

public enum MaxHeight {
    Absolute,
    Relative;

    private static final MaxHeight[] field45 = method38();

    private static MaxHeight[] method38() {
        return new MaxHeight[]{Absolute, Relative};
    }
}
