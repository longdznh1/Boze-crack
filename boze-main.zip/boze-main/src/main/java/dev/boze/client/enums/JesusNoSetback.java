package dev.boze.client.enums;

public enum JesusNoSetback {
    Off,
    Water,
    Lava,
    Both;

    private static final JesusNoSetback[] field1645 = method764();

    private static JesusNoSetback[] method764() {
        return new JesusNoSetback[]{Off, Water, Lava, Both};
    }
}
