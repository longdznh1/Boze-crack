package dev.boze.client.events;

public class PostTickEvent {
    private static final PostTickEvent field1944 = new PostTickEvent();

    public static PostTickEvent method1088() {
        return field1944;
    }
}
