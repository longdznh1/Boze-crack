package dev.boze.client.enums;

public enum TrackMode {
    Off,
    Track,
    Attack;

    private static final TrackMode[] field1662 = method781();

    private static TrackMode[] method781() {
        return new TrackMode[]{Off, Track, Attack};
    }
}
