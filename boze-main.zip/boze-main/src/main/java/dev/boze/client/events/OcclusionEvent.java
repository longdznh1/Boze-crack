package dev.boze.client.events;

public class OcclusionEvent extends CancelableEvent {
    private static final OcclusionEvent INSTANCE = new OcclusionEvent();

    public static OcclusionEvent method1076() {
        INSTANCE.method1021(false);
        return INSTANCE;
    }
}
