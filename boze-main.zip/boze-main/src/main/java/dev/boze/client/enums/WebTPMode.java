package dev.boze.client.enums;

public enum WebTPMode {
    Normal,
    Horizontal,
    Strict;

    private static final WebTPMode[] field1808 = method918();

    private static WebTPMode[] method918() {
        return new WebTPMode[]{Normal, Horizontal, Strict};
    }
}
