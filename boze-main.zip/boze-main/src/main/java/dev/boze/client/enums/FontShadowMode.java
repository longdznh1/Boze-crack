package dev.boze.client.enums;

public enum FontShadowMode {
    Off,
    Mod,
    Color;

    private static final FontShadowMode[] field1719 = method837();

    private static FontShadowMode[] method837() {
        return new FontShadowMode[]{Off, Mod, Color};
    }
}
