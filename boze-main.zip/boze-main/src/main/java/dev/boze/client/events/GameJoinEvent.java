package dev.boze.client.events;

public class GameJoinEvent {
    private static final GameJoinEvent field1920 = new GameJoinEvent();

    public static GameJoinEvent method1062() {
        return field1920;
    }
}
