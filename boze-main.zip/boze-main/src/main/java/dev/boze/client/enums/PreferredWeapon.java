package dev.boze.client.enums;

public enum PreferredWeapon {
    Sword,
    Axe;

    private static final PreferredWeapon[] field1641 = method760();

    private static PreferredWeapon[] method760() {
        return new PreferredWeapon[]{Sword, Axe};
    }
}
