package dev.boze.client.font;

import dev.boze.client.api.BozeDrawColor;

class FontDescriptor {
    String field147;
    double field148;
    double field149;
    int field150;
    boolean field151;
    BozeDrawColor field152;
    double field153;
    double field154;

    FontDescriptor(String var1, double var2, double var4, int var6) {
        this(var1, var2, var4, var6, false, null, 1.0, 1.0);
    }

    FontDescriptor(String var1, double var2, double var4, int var6, boolean var7, BozeDrawColor var8, double var9, double var11) {
        this.field147 = var1;
        this.field148 = var2;
        this.field149 = var4;
        this.field150 = var6;
        this.field151 = var7;
        this.field152 = var8;
        this.field153 = var9;
        this.field154 = var11;
    }
}
