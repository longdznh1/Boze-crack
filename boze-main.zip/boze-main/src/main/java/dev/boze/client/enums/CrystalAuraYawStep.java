package dev.boze.client.enums;

public enum CrystalAuraYawStep {
    Off,
    Break,
    Full;

    private static final CrystalAuraYawStep[] field1642 = method761();

    private static CrystalAuraYawStep[] method761() {
        return new CrystalAuraYawStep[]{Off, Break, Full};
    }
}
