package dev.boze.client.core;

class LogMessage {
    final long field1869 = System.currentTimeMillis();
    final String field1870;
    final String field1871;

    LogMessage(String var1, String var2) {
        this.field1870 = var2;
        this.field1871 = var1;
    }
}
