package dev.boze.client.enums;

public enum NukerShader {
    Normal,
    Image;

    private static final NukerShader[] field1720 = method838();

    private static NukerShader[] method838() {
        return new NukerShader[]{Normal, Image};
    }
}
