package dev.boze.client.enums;

public enum BreakHighlightMode {
    Grow,
    Shrink,
    Cross,
    Static;

    private static final BreakHighlightMode[] field1674 = method793();

    private static BreakHighlightMode[] method793() {
        return new BreakHighlightMode[]{Grow, Shrink, Cross, Static};
    }
}
