package dev.boze.client.enums;

public enum BreadcrumbsLimit {
    Off,
    Length,
    Fade;

    private static final BreadcrumbsLimit[] field1665 = method784();

    private static BreadcrumbsLimit[] method784() {
        return new BreadcrumbsLimit[]{Off, Length, Fade};
    }
}
