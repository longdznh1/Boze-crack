package dev.boze.client.enums;

public enum GUILayout {
    Classic,
    Compact;

    private static final GUILayout[] field1774 = method885();

    private static GUILayout[] method885() {
        return new GUILayout[]{Classic, Compact};
    }
}
