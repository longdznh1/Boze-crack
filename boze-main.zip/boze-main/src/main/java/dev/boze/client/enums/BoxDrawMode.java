package dev.boze.client.enums;

public enum BoxDrawMode {
    Complex,
    Simple,
    Flat;

    private static final BoxDrawMode[] field1739 = method854();

    private static BoxDrawMode[] method854() {
        return new BoxDrawMode[]{Complex, Simple, Flat};
    }
}
