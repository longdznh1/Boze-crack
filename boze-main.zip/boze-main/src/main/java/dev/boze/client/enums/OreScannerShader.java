package dev.boze.client.enums;

public enum OreScannerShader {
    Normal,
    Image;

    private static final OreScannerShader[] field1666 = method785();

    private static OreScannerShader[] method785() {
        return new OreScannerShader[]{Normal, Image};
    }
}
