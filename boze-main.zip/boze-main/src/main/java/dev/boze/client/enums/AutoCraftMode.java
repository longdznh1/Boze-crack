package dev.boze.client.enums;

public enum AutoCraftMode {
    Store,
    Drop;

    private static final AutoCraftMode[] field1687 = method806();

    private static AutoCraftMode[] method806() {
        return new AutoCraftMode[]{Store, Drop};
    }
}
