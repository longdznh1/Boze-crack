package dev.boze.client.enums;

public enum BacktrackMode {
    Once,
    Smart;

    private static final BacktrackMode[] field1702 = method822();

    private static BacktrackMode[] method822() {
        return new BacktrackMode[]{Once, Smart};
    }
}
