package dev.boze.client.enums;

public enum PlayerOverlay {
    Fire,
    Liquid,
    Wall,
    Pumpkin;

    private static final PlayerOverlay[] field1806 = method916();

    private static PlayerOverlay[] method916() {
        return new PlayerOverlay[]{Fire, Liquid, Wall, Pumpkin};
    }
}
