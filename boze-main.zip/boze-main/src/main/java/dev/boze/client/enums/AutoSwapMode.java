package dev.boze.client.enums;

public enum AutoSwapMode {
    Sword,
    Axe,
    Both;

    private static final AutoSwapMode[] field1733 = method850();

    private static AutoSwapMode[] method850() {
        return new AutoSwapMode[]{Sword, Axe, Both};
    }
}
