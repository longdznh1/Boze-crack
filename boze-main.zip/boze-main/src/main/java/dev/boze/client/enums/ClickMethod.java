package dev.boze.client.enums;

public enum ClickMethod {
    Normal,
    Vanilla,
    Dynamic;

    // $VF: synthetic method
    private static ClickMethod[] method797() {
        return new ClickMethod[]{Normal, Vanilla, Dynamic};
    }
}
