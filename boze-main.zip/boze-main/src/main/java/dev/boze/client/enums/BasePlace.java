package dev.boze.client.enums;

public enum BasePlace {
    Off,
    Bind,
    Auto;

    private static final BasePlace[] field1652 = method771();

    private static BasePlace[] method771() {
        return new BasePlace[]{Off, Bind, Auto};
    }
}
