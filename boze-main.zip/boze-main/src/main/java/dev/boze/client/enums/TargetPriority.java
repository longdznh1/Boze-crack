package dev.boze.client.enums;

public enum TargetPriority {
    Highest,
    Lowest;

    private static final TargetPriority[] field1695 = method814();

    private static TargetPriority[] method814() {
        return new TargetPriority[]{Highest, Lowest};
    }
}
