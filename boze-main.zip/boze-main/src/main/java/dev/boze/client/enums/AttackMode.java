package dev.boze.client.enums;

public enum AttackMode {
    Vanilla,
    Packet;

    private static final AttackMode[] field1710 = method828();

    private static AttackMode[] method828() {
        return new AttackMode[]{Vanilla, Packet};
    }
}
