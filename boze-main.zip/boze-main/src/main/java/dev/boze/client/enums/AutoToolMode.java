package dev.boze.client.enums;

public enum AutoToolMode {
    Anarchy,
    Ghost;

    private static final AutoToolMode[] field30 = method25();

    private static AutoToolMode[] method25() {
        return new AutoToolMode[]{Anarchy, Ghost};
    }
}
