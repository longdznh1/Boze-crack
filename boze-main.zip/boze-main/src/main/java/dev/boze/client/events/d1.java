package dev.boze.client.events;

public class d1 extends CancelableEvent {
}
