package dev.boze.client.enums;

public enum AutoSelectPriority {
    Bomber,
    SurroundPP,
    Surround;

    private static final AutoSelectPriority[] field1646 = method765();

    private static AutoSelectPriority[] method765() {
        return new AutoSelectPriority[]{Bomber, SurroundPP, Surround};
    }
}
