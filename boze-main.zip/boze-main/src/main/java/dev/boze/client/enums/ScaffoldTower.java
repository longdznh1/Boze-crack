package dev.boze.client.enums;

public enum ScaffoldTower {
    Off,
    Normal,
    Fast;

    private static final ScaffoldTower[] field1724 = method842();

    private static ScaffoldTower[] method842() {
        return new ScaffoldTower[]{Off, Normal, Fast};
    }
}
