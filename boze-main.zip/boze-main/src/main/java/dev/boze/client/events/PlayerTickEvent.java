package dev.boze.client.events;

import net.minecraft.client.network.ClientPlayerEntity;

public class PlayerTickEvent {
    public ClientPlayerEntity field1941;
}
