package dev.boze.client.events;

public class PreTickEvent {
    private static final PreTickEvent field1945 = new PreTickEvent();

    public static PreTickEvent method1092() {
        return field1945;
    }
}
