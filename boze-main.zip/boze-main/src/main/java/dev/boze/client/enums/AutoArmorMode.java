package dev.boze.client.enums;

public enum AutoArmorMode {
    Anarchy,
    Ghost;

    private static final AutoArmorMode[] field1795 = method906();

    private static AutoArmorMode[] method906() {
        return new AutoArmorMode[]{Anarchy, Ghost};
    }
}
