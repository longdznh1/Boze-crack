package dev.boze.api.internal.interfaces;

public interface IInput {
    String getKeyName(int key);

    String getButtonName(int button);
}
