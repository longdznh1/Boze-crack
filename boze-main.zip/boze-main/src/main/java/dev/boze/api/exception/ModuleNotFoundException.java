package dev.boze.api.exception;

public class ModuleNotFoundException extends Exception {
    public ModuleNotFoundException(String message) {
        super(message);
    }
}
