package de.florianmichael.waybackauthlib;

import com.mojang.authlib.properties.Property;

import java.util.List;

class User {
    public String field240;
    public List<Property> field241;

    private User() {
    }
}
