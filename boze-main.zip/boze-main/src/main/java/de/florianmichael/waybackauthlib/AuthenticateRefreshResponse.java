package de.florianmichael.waybackauthlib;

import com.mojang.authlib.GameProfile;

class AuthenticateRefreshResponse extends Response {
    public String field235;
    public String field236;
    public GameProfile field237;
    public GameProfile[] field238;
    public User field239;

    private AuthenticateRefreshResponse() {
        super();
    }
}
