package de.florianmichael.waybackauthlib;

class Response {
    public String field232;
    public String field233;
    public String field234;
}